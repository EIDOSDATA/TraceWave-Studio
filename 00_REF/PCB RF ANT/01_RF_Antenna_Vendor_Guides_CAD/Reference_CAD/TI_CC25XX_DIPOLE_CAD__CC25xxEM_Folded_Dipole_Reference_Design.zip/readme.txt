   
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X                                                                           X
X   Artwork and documentation done by: Texas Instruments /A. Andersen       X
X                                                                           X
X   Company: Texas Instrument                       		            X
X   Address: Gaustadalleen 21    0349 OSLO                                  X
X                                                                           X
X   Phone  : +47 22 95 85 44   Fax :  +47 22 95 85 46                       X
X                                                                           X
X                                                                           X
X                                                                           X
X                                                                           X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROJECT : 02552
PCB NAME : CC2500EM_FD
REVISION: 1.1
DATE: 2005-11-21


Manufacturers marking: Two letter + year + week
The two letter code shall identify the manufaturer and is decided by the manufacturer. 
No logos or other identifyers are allowed.
The marking shall be in silk screen print at secondary side of the PCB, or in solder 
resist if no silk print at secondary side.


FILE: CC2500EM_FD_PCB_1_1.ZIP PACKED WITH WinZIP 

PCB DESCRIPTION:2 LAYER PCB 0.8 MM NOMINAL THICKNESS FR4 WITH 0.35um Cu PER LAYER
		Dimensions in mil (0.001 inch)
                DOUBLE SIDE SOLDER MASK,
                DOUBLE SIDE SILKSCREEN,
                8 MIL MIN TRACE WIDTH AND 8 MIL MIN ISOLATION
		Dielectric constant for FR4 is 4.5

                 
FILE NAME            			DESCRIPTION                               	FILE TYPE
---------------------------------------------------------------------------------------------------
***PCB MANUFACTURING FILES:
L1.SPL               			LAYER 1 COMPONENT SIDE/POSITIV            	EXT. GERBER
L2.SPL              			LAYER 2 SOLDER SIDE/POSITIV               	EXT. GERBER

STOPCOMP.SPL         			SOLDER MASK COMPONENT SIDE/NEGATIVE             EXT. GERBER
STOPSOLD.SPL         			SOLDER MASK SOLDER SIDE/NEGATIVE                EXT. GERBER

SILKCOMP.SPL         			SILKSCREEN COMPONENT SIDE/POSITIVE            	EXT. GERBER
SILKSOLD.SPL				SILKSCREEN SOLDER SIDE/POSITIVE			EXT. GERBER

NCDRILL.SPL          			NC DRILL THROUGH HOLE                     	EXCELLON
NCDRILL.REP				NC DRILL REPORT					ASCII
DRILL.SPL            			DRILL/MECHANICAL DRAWING                  	EXT. GERBER
DRILL.REP				DRILL REPORT					ASCII
	
EXT_GERBER.USR	     			EXTENDED GERBER APERTURE TABLE 			ASCII
CNC.USR		     			NC DRILL DEVICE FILE				ASCII

***PDF FILES
CC2500EM_FD_schematic_1_1.PDF		SCHEMATIC FILE				 	PDF
ASSYCOMP.PDF        			ASSEMBLY DRAWING COMPONENT SIDE          	PDF
ASSYSOLD.PDF        			SSEMBLY DRAWING SOLDER SIDE          		PDF

CC2500EM_FD_PURCHASE_LIST_1_1.xls 	PART LIST					XLS
								

README.TXT           		THIS FILE     

               
END.
